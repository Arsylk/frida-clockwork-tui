package main

import (
	"fmt"
	"os"
	"reflect"
)

type Database struct {
	devices []Device
}

type Device interface{
	GetId() string
}

type DeviceRenderer interface {
	
}

type Laptop struct {
	name string
	mac string
}

func (d Laptop) GetId() string {
	return d.mac 
}

type Phone struct {
	name string
	imei string
}

func (d Phone) GetId() string {
	return d.imei 
}

func main() {
	laptop := Laptop{
		name: "Dell",
		mac: "43:23:fc:ac:11:89:0c",
	}
	phone := Phone{
		name: "Xiaomi",
		imei: "1294372843334",
	}

	db := Database{
		devices: make([]Device, 0),
	}
	db.devices = append(db.devices, &laptop)
	db.devices = append(db.devices, &phone)

	fmt.Fprintf(os.Stdout, "%#v\n", reflect.ValueOf(db.devices).Pointer())
	for _, dev := range db.devices {
		println(dev.GetId())
	}
	DoSomeStuff(&db.devices)
	fmt.Fprintf(os.Stdout, "%#v\n", reflect.ValueOf(db.devices).Pointer())
	for _, dev := range db.devices {
		println(dev.GetId())
	}
}
func DoSomeStuff(devices *[]Device) {
	fmt.Fprintf(os.Stdout, "%#v\n", reflect.ValueOf(devices).Pointer())
	for _, device := range *devices {
		fmt.Fprintf(os.Stdout, "%#v\n", reflect.ValueOf(device).Pointer())
		DoItemStuff(device)
	}
}

func DoItemStuff(device Device) {
	fmt.Fprintf(os.Stdout, "%#v -> %p\n", device, device)
	switch dev := device.(type) {
	case *Laptop:
		dev.mac = "nya"
	case *Phone:
		dev.imei = "boop"
	}
}