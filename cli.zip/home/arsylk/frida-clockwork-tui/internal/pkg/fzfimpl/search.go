package fzfimpl

import (
	"cmp"
	"slices"
	"strings"
	"sync"
	"unicode/utf8"
)

type SearchOptions struct {
	caseSensitive bool
}

type SearchOption = func(*SearchOptions)

var (
	defaultOptions = SearchOptions{
		caseSensitive: false,
	}
)

// todo maybe rework
type Match struct {
	Str            string
	Index          int
	MatchedIndexes []int
}

type Matches = []Match

func Search(dataset Dataset, query *string, opts... SearchOption) Matches {
	opt := defaultOptions
	for _, o := range opts {
		o(&opt)
	}

	_query := *query
	if !opt.caseSensitive {
		_query = strings.ToLower(*query)
	}

	result := make(Matches, 0, dataset.Len())
	mutex := sync.Mutex{}
	wg := sync.WaitGroup{}

	// Set the number of workers and chunk size.
	numWorkers := 8
	chunkSize := (dataset.Len() + numWorkers - 1) / numWorkers
	chunks := make(chan int, numWorkers)
	
	// Launch the workers.
	for i := 0; i < numWorkers; i+=1 {
		wg.Add(1)
		go func() {
			defer wg.Done()

			// Perform the search for each chunk.
			for start := range chunks {
				end := start + chunkSize
				if end > dataset.Len() {
					end = dataset.Len()
				}

				// Create a slice to store local matches for each chunk.
				localMatches := make(Matches, 0)

				// Perform the search for each item.
				for index := start; index < end; index++ {
					m, ok := fuzzySearch(*dataset.GetText(index), _query, opt)
					if ok {
						m.Index = index
						localMatches = append(localMatches, m)
					}
				}

				// Add the local matches to the result (while performing mutual exclusion).
				mutex.Lock()
				result = append(result, localMatches...)
				mutex.Unlock()
			}
		}()
	}

	// Assign chunks to the workers.
	for i := 0; i < dataset.Len(); i += chunkSize {
		chunks <- i
	}

	//Once all chunks are assigned, close the channel.
	close(chunks)

	// Wait for all workers to complete their processing.
	wg.Wait()

	// Sort the search results and return them.
	slices.SortFunc(result, func(a, b Match) int { return cmp.Compare(a.Index, b.Index) })

	return result
}

func fuzzySearch(str string, search string, opt SearchOptions) (Match, bool) {
	item := str

	// If case-insensitive, convert the item to lowercase.
	if !opt.caseSensitive {
		item = strings.ToLower(item)
	}

	// Create a slice to store the matched indexes.
	matchedIndexes := make([]int, 0, utf8.RuneCountInString(search))
	j := 0

	// Check for matching between the item's characters and the search string.
	searchRunes := []rune(search)
	for i, r := range []rune(item) {
		if j < len(searchRunes) && r == searchRunes[j] {
			matchedIndexes = append(matchedIndexes, i)
			j+=1
		}
	}

	// Returns Match if all characters in the search string match.
	if j == len(searchRunes) {
		return Match{Str: str, MatchedIndexes: matchedIndexes}, true
	} else {
		return Match{}, false
	}
}
