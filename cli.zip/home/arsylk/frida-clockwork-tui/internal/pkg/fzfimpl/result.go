package fzfimpl

type Result struct {
	Item   IItem
	points [4]uint16
}