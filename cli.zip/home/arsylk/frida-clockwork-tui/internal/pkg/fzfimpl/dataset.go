package fzfimpl

import fzf "github.com/junegunn/fzf/src"

type Dataset interface {
	Len() int
	GetText(index int) *string
	Items()	*[]Item
}

type ListDataset[T any] struct {
	list *[]T
	items *[]Item
	mapper func(index int, item T) *string
}

func NewListDataset[T any](list *[]T, mapper func(index int, item T) *string) *ListDataset[T] {
	items := make([]Item, len(*list))
	for i := range *list {
		items[i] = Item{int32(i)}
	}
	dataset := &ListDataset[T]{
		list: list,
		items: &items,
		mapper: mapper,
	} 

	return dataset
}

func (ds ListDataset[T]) Len() int {
	return len(*ds.list)
}

func (ds ListDataset[T]) GetText(index int) *string {
	return ds.mapper(index, (*ds.list)[index])	
}
func (ds ListDataset[T]) Items() *[]Item {
	return ds.items
}

type ListDataSubset[T any] struct {
	Dataset
	query string 
	items []Item // index -> item index 
}

func NewListDataSubset[T any](dataset Dataset, query string, results []fzf.Result) *ListDataSubset[T] {
	items := make([]Item, len(results))
	for i, result := range results {
		items[i] = Item{index: result.Index()}
	}

	return &ListDataSubset[T]{
		Dataset: dataset,
		query: query,
		items: items,
	}
}