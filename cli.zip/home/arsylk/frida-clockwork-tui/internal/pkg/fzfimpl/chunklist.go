package fzfimpl

import "sync"

// Chunk is a list of Items whose size has the upper limit of chunkSize
type Chunk[T any] struct {
	items [chunkSize]T
	count int
}

// ItemBuilder is a closure type that builds Item object from byte array
type ItemBuilder[T any, R any] func(item *T, data R) bool

// ChunkList is a list of Chunks
type ChunkList[T any, R any] struct {
	chunks []*Chunk[T]
	mutex  sync.Mutex
	trans  ItemBuilder[T, R]
}

// NewChunkList returns a new ChunkList
func NewChunkList[T any, R any](trans ItemBuilder[T, R]) *ChunkList[T, R] {
	return &ChunkList[T,R ]{
		chunks: []*Chunk[T]{},
		mutex:  sync.Mutex{},
		trans:  trans,
	}
}

func pushChunk[T any, R any](c *Chunk[T], trans ItemBuilder[T, R], data R) bool {
	if trans(&c.items[c.count], data) {
		c.count+=1
		return true
	}
	return false
}

// IsFull returns true if the Chunk is full
func (c *Chunk[T]) IsFull() bool {
	return c.count == chunkSize
}

func (cl *ChunkList[T, R]) lastChunk() *Chunk[T] {
	return cl.chunks[len(cl.chunks)-1]
}

// CountItems returns the total number of Items
func CountItems[T any](cs []*Chunk[T]) int {
	if len(cs) == 0 {
		return 0
	}
	return chunkSize*(len(cs)-1) + cs[len(cs)-1].count
}

// Push adds the item to the list
func (cl *ChunkList[T, R]) Push(data R) bool {
	cl.mutex.Lock()

	if len(cl.chunks) == 0 || cl.lastChunk().IsFull() {
		cl.chunks = append(cl.chunks, &Chunk[T]{})
	}

	ret := pushChunk(cl.lastChunk(), cl.trans, data)
	cl.mutex.Unlock()
	return ret
}

// Clear clears the data
func (cl *ChunkList[_, _]) Clear() {
	cl.mutex.Lock()
	cl.chunks = nil
	cl.mutex.Unlock()
}

// Snapshot returns immutable snapshot of the ChunkList
func (cl *ChunkList[T, _]) Snapshot() ([]*Chunk[T], int) {
	cl.mutex.Lock()

	ret := make([]*Chunk[T], len(cl.chunks))
	copy(ret, cl.chunks)

	// Duplicate the last chunk
	if cnt := len(ret); cnt > 0 {
		newChunk := *ret[cnt-1]
		ret[cnt-1] = &newChunk
	}

	cl.mutex.Unlock()
	return ret, CountItems(ret)
}
