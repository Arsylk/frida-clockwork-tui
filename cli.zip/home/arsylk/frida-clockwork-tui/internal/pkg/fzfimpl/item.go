package fzfimpl

import (
	"regexp"
)

type IItem interface {
	Intex() int
}

type Item struct {
	index int32
}

type Items = []Item

var (
	linesPattern = regexp.MustCompile(`\n+`)
)

func (item *Item) Index() int32 {
	return item.index
}