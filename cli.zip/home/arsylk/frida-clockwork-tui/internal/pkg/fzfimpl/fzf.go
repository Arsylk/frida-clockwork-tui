package fzfimpl

import (
	fzf "github.com/junegunn/fzf/src"
	"github.com/junegunn/fzf/src/util"
)


func FilterOption(query string) Option  {
	return func(opts *fzf.Options) {
		(*opts).Filter = &query
	}
}

type Option = func(*fzf.Options) 

func Run[T any, R any](chunklist *ChunkList[T, R], options... Option) []fzf.Result {
	opts := *fzf.DefaultOptions()
	for _, o := range options {
		o(&opts)
	}

	sort := opts.Sort > 0

	// Event channel
	eventBox := util.NewEventBox()

	// Matcher
	forward := true
	withPos := false
	for idx := len(opts.Criteria) - 1; idx > 0; idx-- {
		switch opts.Criteria[idx] {
		case fzf.ByChunk:
			withPos = true
		case fzf.ByEnd:
			forward = false
		case fzf.ByBegin:
			forward = true
		}
	}
	patternBuilder := func(runes []rune) *fzf.Pattern {
		return fzf.BuildPattern(
			opts.Fuzzy, opts.FuzzyAlgo, opts.Extended, opts.Case, opts.Normalize, forward, withPos,
			opts.Filter == nil, opts.Nth, opts.Delimiter, runes)
	}
	inputRevision := 0
	matcher := NewMatcher(patternBuilder, sort, opts.Tac, eventBox, inputRevision)

	// Filtering mode
	var result []fzf.Result 
	{
		pattern := patternBuilder([]rune(*opts.Filter))
		matcher.sort = pattern.Sortable

		{
			eventBox.WaitFor(fzf.EvtReadFin)

			snapshot, _ := chunklist.Snapshot()
			merger, _ := Scan(
				matcher, MatchRequest[T]{
					Chunks:  snapshot,
					Pattern: pattern,
				},
			)
			result = make([]fzf.Result, merger.Length())

			for i := 0; i < merger.Length(); i++ {
				result[i] = merger.Get(i)
			}
		}
	}

	return result
}