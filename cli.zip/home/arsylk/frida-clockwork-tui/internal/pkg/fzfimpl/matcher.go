package fzfimpl

import (
	"fmt"
	"runtime"
	"sort"
	"sync"
	"time"

	fzf "github.com/junegunn/fzf/src"
	"github.com/junegunn/fzf/src/util"
)

// MatchRequest represents a search request
type MatchRequest[T any] struct {
	Chunks   []*Chunk[T]
	Pattern  *fzf.Pattern
	final    bool
	sort     bool
	revision int
}

// Matcher is responsible for performing search
type Matcher struct {
	patternBuilder func([]rune) *fzf.Pattern
	sort           bool
	tac            bool
	eventBox       *util.EventBox
	reqBox         *util.EventBox
	partitions     int
	slab           []*util.Slab
	mergerCache    map[string]*fzf.Merger
	revision       int
}

const (
	reqRetry util.EventType = iota
	reqReset
)

// NewMatcher returns a new Matcher
func NewMatcher(patternBuilder func([]rune) *fzf.Pattern,
	sort bool, tac bool, eventBox *util.EventBox, revision int) *Matcher {
	partitions := util.Min(numPartitionsMultiplier*runtime.NumCPU(), maxPartitions)
	return &Matcher{
		patternBuilder: patternBuilder,
		sort:           sort,
		tac:            tac,
		eventBox:       eventBox,
		reqBox:         util.NewEventBox(),
		partitions:     partitions,
		slab:           make([]*util.Slab, partitions),
		mergerCache:    make(map[string]*fzf.Merger),
		revision:       revision}
}

// Loop puts Matcher in action
func Loop[T any](m *Matcher) {
	prevCount := 0

	for {
		var request MatchRequest[T]

		m.reqBox.Wait(func(events *util.Events) {
			for _, val := range *events {
				switch val := val.(type) {
				case MatchRequest[T]:
					request = val
				default:
					panic(fmt.Sprintf("Unexpected type: %T", val))
				}
			}
			events.Clear()
		})

		if request.sort != m.sort || request.revision != m.revision {
			m.sort = request.sort
			m.revision = request.revision
			m.mergerCache = make(map[string]*fzf.Merger)
			fzf.ClearChunkCache()
		}

		// Restart search
		patternString := request.Pattern.AsString()
		var merger *fzf.Merger
		cancelled := false
		count := CountItems(request.Chunks)

		foundCache := false
		if count == prevCount {
			// Look up mergerCache
			if cached, found := m.mergerCache[patternString]; found {
				foundCache = true
				merger = cached
			}
		} else {
			// Invalidate mergerCache
			prevCount = count
			m.mergerCache = make(map[string]*fzf.Merger)
		}

		if !foundCache {
			merger, cancelled = Scan[T](m, request)
		}

		if !cancelled {
			if merger.Cacheable() {
				m.mergerCache[patternString] = merger
			}
			merger.Final = request.final
			m.eventBox.Set(fzf.EvtSearchFin, merger)
		}
	}
}

func sliceChunks[T any](m *Matcher, chunks []*Chunk[T]) [][]*Chunk[T] {
	partitions := m.partitions
	perSlice := len(chunks) / partitions

	if perSlice == 0 {
		partitions = len(chunks)
		perSlice = 1
	}

	slices := make([][]*Chunk[T], partitions)
	for i := 0; i < partitions; i++ {
		start := i * perSlice
		end := start + perSlice
		if i == partitions-1 {
			end = len(chunks)
		}
		slices[i] = chunks[start:end]
	}
	return slices
}

type partialResult struct {
	index   int
	matches []fzf.Result
}

func Scan[T any](m *Matcher, request MatchRequest[T]) (*fzf.Merger, bool) {
	startedAt := time.Now()

	numChunks := len(request.Chunks)
	if numChunks == 0 {
		return fzf.EmptyMerger(request.revision), false
	}
	pattern := request.Pattern
	if pattern.IsEmpty() {
		return fzf.PassMerger(&request.Chunks, m.tac, request.revision), false
	}

	cancelled := util.NewAtomicBool(false)

	slices := sliceChunks[T](m, request.Chunks)
	numSlices := len(slices)
	resultChan := make(chan partialResult, numSlices)
	countChan := make(chan int, numChunks)
	waitGroup := sync.WaitGroup{}

	for idx, chunks := range slices {
		waitGroup.Add(1)
		if m.slab[idx] == nil {
			m.slab[idx] = util.MakeSlab(slab16Size, slab32Size)
		}
		go func(idx int, slab *util.Slab, chunks []*Chunk[T]) {
			defer func() { waitGroup.Done() }()
			count := 0
			allMatches := make([][]fzf.Result, len(chunks))
			for idx, chunk := range chunks {
				matches := request.Pattern.Match(chunk, slab)
				allMatches[idx] = matches
				count += len(matches)
				if cancelled.Get() {
					return
				}
				countChan <- len(matches)
			}
			sliceMatches := make([]fzf.Result, 0, count)
			for _, matches := range allMatches {
				sliceMatches = append(sliceMatches, matches...)
			}
			if m.sort {
				if m.tac {
					sort.Sort(fzf.ByRelevanceTac(sliceMatches))
				} else {
					sort.Sort(fzf.ByRelevance(sliceMatches))
				}
			}
			resultChan <- partialResult{idx, sliceMatches}
		}(idx, m.slab[idx], chunks)
	}

	wait := func() bool {
		cancelled.Set(true)
		waitGroup.Wait()
		return true
	}

	count := 0
	matchCount := 0
	for matchesInChunk := range countChan {
		count++
		matchCount += matchesInChunk

		if count == numChunks {
			break
		}

		if m.reqBox.Peek(reqReset) {
			return nil, wait()
		}

		if time.Since(startedAt) > progressMinDuration {
			m.eventBox.Set(fzf.EvtSearchProgress, float32(count)/float32(numChunks))
		}
	}

	partialResults := make([][]fzf.Result, numSlices)
	for range slices {
		partialResult := <-resultChan
		partialResults[partialResult.index] = partialResult.matches
	}
	return fzf.NewMerger(pattern, partialResults, m.sort, m.tac, request.revision), false
}

// Reset is called to interrupt/signal the ongoing search
func (m *Matcher) Reset(chunks []*Chunk[any], patternRunes []rune, cancel bool, final bool, sort bool, revision int) {
	pattern := m.patternBuilder(patternRunes)

	var event util.EventType
	if cancel {
		event = reqReset
	} else {
		event = reqRetry
	}
	m.reqBox.Set(event, MatchRequest[any]{chunks, pattern, final, sort && pattern.Sortable, revision})
}
