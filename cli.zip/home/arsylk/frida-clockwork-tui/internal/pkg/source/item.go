package source

type ChunkItem struct {
	index int32
	pretty string
	nocolor string
}