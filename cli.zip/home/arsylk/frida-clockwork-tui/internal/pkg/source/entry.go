package source

type IEntry interface {
	GetSession() *Session
	Raw() *string
	Tag() *string
	GetRenderAndCache() *string
}

type Entry struct {
	session  *Session
	raw      string
	tag      string
	rendered *string
}

type Entries = []IEntry

func (e Entry) GetSession() *Session {
	return e.session
}
func (e Entry) Raw() *string {
	return &e.raw
}
func (e Entry) Tag() *string {
	return &e.tag
}

func (e *Entry) GetRenderAndCache() *string {
	if e.rendered == nil {
		str := ColorRenderer.Render(e)
		e.rendered = &str
	}
	return e.rendered
}

func FilterEntries(entries *Entries, predicate func(IEntry, int) bool) *Entries {
	length := len(*entries)
	arr := make(Entries, 0, length)
	for i, entry := range *entries {
		if predicate(entry, i) {
			arr = append(arr, entry)
		}
	}

	return &arr
}

// func (e *Entries) Get(i int) IEntry {
// 	rv := *e
// 	return rv[i]
// }
