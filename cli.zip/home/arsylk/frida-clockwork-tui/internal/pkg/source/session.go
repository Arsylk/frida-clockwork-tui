package source

import (
	"github.com/Arsylk/frida-clockwork-tui/internal/pkg/fzfimpl"
)

type Session struct {
	classes map[JvmId]*JvmClass
	methods map[JvmId]*JvmMethod
	entries Entries
	chunklist *fzfimpl.ChunkList[ChunkItem, IEntry]
}

func (s *Session) Classes() map[JvmId]*JvmClass {
	return s.classes
}
func (s *Session) Methods() map[JvmId]*JvmMethod {
	return s.methods
}
func (s *Session) Entries() *Entries {
	return &s.entries
}

func (s *Session) GetArgType(id JvmId, index int) *string {
	if method := s.GetMethod(id); method != nil {
		return &method.a[index]
	}
	return nil
}

func (s *Session) GetReturnType(id JvmId) *string {
	if method := s.GetMethod(id); method != nil {
		return &method.r
	}
	return nil
}

func (s *Session) GetMethod(id JvmId) *JvmMethod {
	if s == nil {
		return nil
	}
	methods := s.Methods()
	if len(methods) == 0 {
		return nil
	}
	return methods[id]
}

func (s * Session) GetEntry(index int) IEntry {
	return s.entries[index]
}

func (s * Session) GetItem(index int) IEntry {
	return s.chunklist.Get(index)
}
