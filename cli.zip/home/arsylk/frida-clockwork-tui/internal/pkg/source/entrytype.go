package source


type JvmId string

type (
	JvmClass struct {
		Entry
		cn string
		id JvmId
	}
	JvmMethod struct {
		Entry
		mn string
		a  []string
		r  string
		id JvmId
	}
	JvmCall struct {
		Entry
		cn string
		mn string
		av []string
		rv string
		id JvmId
		st []string
	}
	JvmReturn struct {
		Entry
		id JvmId
		rv string
	}
)
