package source

import (
	"fmt"
	"strings"

	"github.com/Arsylk/frida-clockwork-tui/internal/pkg/style"
	"github.com/charmbracelet/lipgloss"
)

type RendererOptions struct {
	pretty    bool
	multiline bool
}

type RendererOption = func(*RendererOptions)

type Renderer interface {
	Render(entry IEntry, opts ...RendererOption) string
}

var (
	ColorRenderer = TextRenderer{
		_className:  lipgloss.NewStyle().Foreground(style.Cyan()),
		_methodName: lipgloss.NewStyle().Foreground(style.Green()),
		_bracket:    lipgloss.NewStyle().Foreground(style.Blue()),
		_string:     lipgloss.NewStyle().Foreground(style.Yellow()),
		_number:     lipgloss.NewStyle().Foreground(style.Magenta()),
		_error:      lipgloss.NewStyle().Foreground(style.Red()),
		_unknown:    lipgloss.NewStyle().Foreground(style.White()),
	}
	NoColorRenderer = TextRenderer{
		_className:  lipgloss.NewStyle(),
		_methodName: lipgloss.NewStyle(),
		_bracket:    lipgloss.NewStyle(),
		_string:     lipgloss.NewStyle(),
		_number:     lipgloss.NewStyle(),
		_error:      lipgloss.NewStyle(),
		_unknown:    lipgloss.NewStyle(),
	}
)

type TextRenderer struct {
	_className  lipgloss.Style
	_methodName lipgloss.Style
	_bracket    lipgloss.Style
	_string     lipgloss.Style
	_number     lipgloss.Style
	_error      lipgloss.Style
	_unknown    lipgloss.Style
}

func (t *TextRenderer) renderClassName(cn string) string {
	parts := strings.Split(cn, ".")
	newparts := make([]string, len(parts))
	for i, part := range parts {
		newparts[i] = t._className.Render(part)
	}
	return strings.Join(newparts, ".")
}

func (t *TextRenderer) renderMethodName(mn string) string {
	return t._methodName.Render(mn)
}

func (t *TextRenderer) renderValue(v string, tp *string) string {
	if tp == nil {
		return v
	}

	switch *tp {
	case "int", "float", "double", "long", "byte", "boolean":
		return t._number.Render(v)
	case "char":
		return t._string.Render(fmt.Sprintf("'%s'", v))
	case "java.lang.String", "java.lang.CharSequence":
		return t._string.Render(fmt.Sprintf("\"%s\"", v))
	}
	return fmt.Sprintf("%s%s%s %s", t._bracket.Render("("), t._error.Render(*tp), t._bracket.Render(")"), t._unknown.Render(v))
}

func (t *TextRenderer) Render(entry IEntry, opts ...RendererOption) string {
	switch entry := entry.(type) {
	case *JvmClass:
		return t.RenderJvmClass(entry, opts...)
	case *JvmMethod:
		return t.RenderJvmMethod(entry, opts...)
	case *JvmCall:
		return t.RenderJvmCall(entry, opts...)
	case *JvmReturn:
		return t.RenderJvmReturn(entry, opts...)
	default:
		return fmt.Sprintf("%T", entry)
	}
}

func (t *TextRenderer) RenderJvmClass(entry *JvmClass, opts ...RendererOption) string {
	return fmt.Sprintf("Hooking %s", t.renderClassName(entry.cn))
}

func (t *TextRenderer) RenderJvmMethod(entry *JvmMethod, opts ...RendererOption) string {
	args := make([]string, len(entry.a))
	for i, arg := range entry.a {
		args[i] = t.renderClassName(arg)
	}
	return fmt.Sprintf("  >%s%s%s%s: %s", t.renderMethodName(entry.mn), t._bracket.Render("("), strings.Join(args, ", "), t._bracket.Render(")"), t.renderClassName(entry.r))
}

func (t *TextRenderer) RenderJvmCall(entry *JvmCall, opts ...RendererOption) string {
	args := make([]string, len(entry.av))
	for i, arg := range entry.av {
		args[i] = t.renderValue(arg, entry.GetSession().GetArgType(entry.id, i))
	}
	if entry.mn == "$init" {
		return fmt.Sprintf("call new %s%s%s%s", t.renderClassName(entry.cn), t._bracket.Render("("), strings.Join(args, ", "), t._bracket.Render(")"))
	}
	return fmt.Sprintf("call %s::%s%s%s%s: %s", t.renderClassName(entry.cn), t.renderMethodName(entry.mn), t._bracket.Render("("), strings.Join(args, ", "), t._bracket.Render(")"), t.renderClassName(entry.rv))
}

func (t *TextRenderer) RenderJvmReturn(entry *JvmReturn, opts ...RendererOption) string {
	value := t.renderValue(entry.rv, entry.GetSession().GetReturnType(entry.id))
	return fmt.Sprintf("return %s", value)
}
