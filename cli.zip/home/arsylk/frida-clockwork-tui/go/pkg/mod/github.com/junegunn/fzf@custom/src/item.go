package fzf

import (
	"github.com/junegunn/fzf/src/util"
)

// Item represents each input line. 56 bytes.
type Item struct {
	Text        util.Chars    // 32 = 24 + 1 + 1 + 2 + 4
	Transformed *[]Token      // 8
	OrigText    *[]byte       // 8
	Colored     *[]AnsiOffset // 8
}

// Index returns ordinal index of the Item
func (item *Item) Index() int32 {
	return item.Text.Index
}

var minItem = Item{Text: util.Chars{Index: -1}}

func (item *Item) TrimLength() uint16 {
	return item.Text.TrimLength()
}

// Colors returns ansiOffsets of the Item
func (item *Item) Colors() []AnsiOffset {
	if item.Colored == nil {
		return []AnsiOffset{}
	}
	return *item.Colored
}

// AsString returns the original string
func (item *Item) AsString(stripAnsi bool) string {
	if item.OrigText != nil {
		if stripAnsi {
			trimmed, _, _ := ExtractColor(string(*item.OrigText), nil, nil)
			return trimmed
		}
		return string(*item.OrigText)
	}
	return item.Text.ToString()
}
