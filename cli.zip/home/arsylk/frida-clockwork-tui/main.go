package main

import (
	"fmt"
	"os"

	"github.com/Arsylk/frida-clockwork-tui/internal/app"
	tea "github.com/charmbracelet/bubbletea"
)

func main() {
	var pathArg string = os.Args[1]
	if _, err := os.Stat(pathArg); err != nil {
		fatalf("error reading file \"%s\": %v\n", pathArg, err)
	}
	pathLog := "debug.log"

	appModel, application := app.NewModel(pathArg, pathLog)
	defer application.Close()
	program := tea.NewProgram(
		appModel,
		tea.WithAltScreen(),
	)

	if _, err := program.Run(); err != nil {
		fatalf("program error: %v\n", err)
	}
}

func fatalf(message string, args ...any) {
	_, _ = fmt.Fprintf(os.Stderr, message, args...)
	os.Exit(1)
}
